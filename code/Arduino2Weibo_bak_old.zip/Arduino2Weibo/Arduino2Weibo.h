/*
  Arduino2Weibo.cpp - Arduino library to Post messages to Weibo using OAuth.
  Copyright (c) naozhendang.com 2011-2012. 
  
  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 
	More information can be found at:  http://arduino2weibo.sinaapp.com
*/

// ver0.2 - Support IDE 1.0

#ifndef ARDUINO2WEIBO_H
#define ARDUINO2WEIBO_H

#include <inttypes.h>
#include <avr/pgmspace.h>
#if defined(ARDUINO) && ARDUINO > 18   // Arduino 0019 or later
#include <SPI.h>
#endif
#include <Ethernet.h>
#if defined(ARDUINO) && ARDUINO < 100  // earlier than Arduino 1.0
#include <EthernetDNS.h>
#endif

class Weibo
{
private:
	const char *token;
	const char *token_secret;
#if defined(ARDUINO) && ARDUINO < 100
	Client client;
#else
	EthernetClient client;
#endif
	uint16_t freeMem(uint16_t *biggest);
	
public:
	Weibo(const char *token, const char *token_secret);
	
	//http requests
	bool unread(int with_new_status = 0, const char *since_id = NULL);
	bool post(const char *msg);
	bool atme(const char *since_id = NULL);
	bool home_timeline(const char *since_id = NULL);
	bool user_timeline(const char *since_id = NULL);
	bool reset_count(int type);
	bool user_counts(const char *uid);
	
	//data parsers
	char* return_data(); 
	int json_length(char* json);
	int value_length(char* json);
	char* value_pointer(char* key, char* json);
	short compare_strings(char* string1, char* string2);
	char* find_substring(char* string1, char* string2);
	int compile_digits(char* value);

	//other tools 
	void freeMem(char* message);
        void printProgStr(const prog_char* str);
};

#endif	//ARDUINO2WEIBO_H
